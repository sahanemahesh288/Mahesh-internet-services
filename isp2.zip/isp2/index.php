<?php include 'includes/header.php'; ?>

<TODO Display tables or home page >
<!-- <a href="products.php">
   <figure>
      <img src="component/img/products.jpg" alt="Products" width="1200" height="600" align="center" style="padding: 0px;">
   <strong>   Products</strong>  -->
   <div class="span span3" >
            <a href='customers.php'>
                <img src="component/img/customer.jpg"  width="1200" height="600" align="center" style="padding: 10px;"><br/>
                <div class="homeheading">
                <strong>   Customers </strong> 
</div>
            </a>
        </div>
<!-- </a> -->
<div class="span span3" >
  
            <a href='user.php'>
                <img src="component/img/User.jpg"  width="1200" height="600" align="center" style="padding: 10px;"><br/>
                <div class="homeheading">
                <strong>   Employee </strong>
</div>
            </a>
        </div>

        
<!-- <img src="component/img/ispback.jpg" width="580" height="400" align="right" style="padding: 20px;">
<img src="component/img/ispback.jpg" width="580" height="400" align="left" style="padding: 20px;">
<img src="component/img/ispback.jpg" width="580" height="400" align="right" style="padding: 20px;">     -->

<!-- <img src="component/img/ispback.jpg" style="all: unset  !important;height: 100vh !important; width: 80vw !important;
"> -->



<?php include 'includes/footer.php'; ?>
<script type="text/javascript">
    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
            datasets: [{
                label: 'Cash Collection',
                data: [12, 19, 3, 17, 6, 3, 7],
                backgroundColor: "rgba(153,255,51,0.6)"
            }, {
                label: 'Expance',
                data: [2, 29, 5, 5, 2, 3, 10],
                backgroundColor: "rgba(245,0,0,0.6)"
            }]
        }
    });
    var ctx = document.getElementById('chart2').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Monthly Bill Collection',
                data: [50000, 60000, 30000, 45000, 48000, 38000, 80000, 20000, 0],
                backgroundColor: "rgba(0,255,51,0.6)"
            }]
        }
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $.ajax({
            url: "chart.php",
            method: "GET",
            dataType: 'JSON',
            success: function(data) {
                console.log(data);
                var raw = [];
                var qty = [];

                for (var i in data) {
                    raw.push(data[i].name);
                    qty.push(data[i].quantity);
                }
                console.log(raw);
                console.log(qty);
                var chartdata = {
                    labels: raw,
                    datasets: [{
                        label: 'Product Stock',
                        backgroundColor: 'rgba(0,200,225,.5)',
                        borderColor: 'rgba(200, 200, 200, 0.75)',
                        hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
                        hoverBorderColor: 'rgba(200, 200, 200, 1)',
                        data: qty
                    }]
                };

                var ctx = $('#myChart2');

                var barGraph = new Chart(ctx, {
                    type: 'bar',
                    data: chartdata
                    // options: {
                    //     scales: {
                    //         yAxes: [{
                    //             ticks: {
                    //                 // Create scientific notation labels
                    //                 callback: function(value, index, values) {
                    //                     return value.toExponential();
                    //                 }
                    //             }
                    //         }]
                    //     }
                    // }
                });
            },
            error: function(data) {
                console.log(data);
            }
        });
    });

</script>
